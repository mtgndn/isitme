<?php
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $kategori = trim($_POST['kategori']);
    $marka = trim($_POST['marka']);
    $urun_adi = trim($_POST['urun_adi']);
    $stok_adedi = (int)$_POST['stok_adedi'];

    if ($kategori && $marka && $urun_adi && $stok_adedi >= 0) {
        $stmt = $pdo->prepare("INSERT INTO products (kategori, marka, urun_adi, stok_adedi) VALUES (?, ?, ?, ?)");
        $stmt->execute([$kategori, $marka, $urun_adi, $stok_adedi]);
        $success = "Ürün başarıyla eklendi.";
    } else {
        $error = "Lütfen tüm alanları doğru doldurun.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Ürün Ekle</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="index.php">Stok Takip Sistemi</a>
        <div>
            <span class="navbar-text me-3">Hoşgeldin, <?=htmlspecialchars($_SESSION['admin'])?></span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Çıkış</a>
        </div>
    </div>
</nav>

<div class="container">
    <h2 class="mb-4">Yeni Ürün Ekle</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?=htmlspecialchars($success)?></div>
    <?php endif; ?>

    <form method="post" class="row g-3">

        <div class="col-md-4">
            <label for="kategori" class="form-label">Kategori</label>
            <input type="text" name="kategori" id="kategori" class="form-control" required>
        </div>

        <div class="col-md-4">
            <label for="marka" class="form-label">Marka</label>
            <input type="text" name="marka" id="marka" class="form-control" required>
        </div>

        <div class="col-md-4">
            <label for="urun_adi" class="form-label">Ürün Adı</label>
            <input type="text" name="urun_adi" id="urun_adi" class="form-control" required>
        </div>

        <div class="col-md-4">
            <label for="stok_adedi" class="form-label">Stok Adedi</label>
            <input type="number" name="stok_adedi" id="stok_adedi" class="form-control" min="0" required>
        </div>

        <div class="col-12">
            <button type="submit" class="btn btn-success">Ekle</button>
            <a href="index.php" class="btn btn-secondary ms-2">Geri</a>
        </div>

    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
