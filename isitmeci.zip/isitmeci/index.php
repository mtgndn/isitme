<?php
require 'config.php'; 

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$kategori = $_POST['kategori'] ?? '';
$marka = $_POST['marka'] ?? '';
$urun = $_POST['urun'] ?? '';

$stokAdedi = null;
$satildi = false;
$error = '';


$kategoriStmt = $pdo->query("SELECT DISTINCT kategori FROM products ORDER BY kategori ASC");
$kategoriler = $kategoriStmt->fetchAll(PDO::FETCH_COLUMN);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($kategori && $marka && $urun) {
        
        $stmt = $pdo->prepare("SELECT * FROM products WHERE kategori = ? AND marka = ? AND urun_adi = ?");
        $stmt->execute([$kategori, $marka, $urun]);
        $product = $stmt->fetch();

        if ($product) {
            $stokAdedi = (int)$product['stok_adedi'];

            if (isset($_POST['sat'])) {
                
                if ($stokAdedi > 0) {
                    $stokAdedi--;
                    $updateStmt = $pdo->prepare("UPDATE products SET stok_adedi = ? WHERE id = ?");
                    $updateStmt->execute([$stokAdedi, $product['id']]);
                    $satildi = true;
                } else {
                    $error = "Stokta yeterli ürün yok.";
                }
            }
        } else {
            $error = "Ürün bulunamadı.";
        }
    } else {
        $error = "Lütfen kategori, marka ve ürün seçiniz.";
    }
}


$allProducts = $pdo->query("SELECT * FROM products ORDER BY kategori, marka, urun_adi")->fetchAll();

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Stok Takip Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
    <div class="container">
        <a class="navbar-brand" href="#">Stok Takip Sistemi</a>
        <div>
            <a href="product_add.php" class="btn btn-outline-light btn-sm me-2">Yeni Ürün Ekle</a>
            <span class="navbar-text me-3">Hoşgeldin, <?=htmlspecialchars($_SESSION['admin'])?></span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Çıkış</a>
        </div>
    </div>
</nav>

<div class="container">

    <h2>Ürün Stok Durumu Sorgulama</h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>

    <?php if ($satildi): ?>
        <div class="alert alert-success">Ürün başarıyla satıldı, stok güncellendi.</div>
    <?php endif; ?>

    <form method="post" class="row g-3">

        <div class="col-md-4">
            <label for="kategori" class="form-label">Kategori</label>
            <select id="kategori" name="kategori" class="form-select" required>
                <option value="">Seçiniz...</option>
                <?php foreach ($kategoriler as $kat): ?>
                    <option value="<?=htmlspecialchars($kat)?>" <?=($kategori == $kat ? 'selected' : '')?>><?=htmlspecialchars($kat)?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-4">
            <label for="marka" class="form-label">Marka</label>
            <select id="marka" name="marka" class="form-select" required>
                <option value="">Önce kategori seçiniz</option>
            </select>
        </div>

        <div class="col-md-4">
            <label for="urun" class="form-label">Ürün</label>
            <select id="urun" name="urun" class="form-select" required>
                <option value="">Önce marka seçiniz</option>
            </select>
        </div>

        <div class="col-12">
            <button type="submit" class="btn btn-primary" name="stok_sorgula">Stok Sorgula</button>

            <?php if ($stokAdedi !== null): ?>
                <span class="ms-3">Stok Adedi: <strong><?= $stokAdedi ?></strong></span>
                <button type="submit" class="btn btn-success ms-3" name="sat" <?= $stokAdedi == 0 ? 'disabled' : '' ?>>SAT</button>
            <?php endif; ?>
        </div>

    </form>

    <hr>

    <h3>Mevcut Ürünler</h3>
    <table class="table table-striped table-hover">
        <thead>
            <tr>
                <th>Kategori</th>
                <th>Marka</th>
                <th>Ürün Adı</th>
                <th>Stok Adedi</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($allProducts as $p): ?>
            <tr>
                <td><?=htmlspecialchars($p['kategori'])?></td>
                <td><?=htmlspecialchars($p['marka'])?></td>
                <td><?=htmlspecialchars($p['urun_adi'])?></td>
                <td><?= (int)$p['stok_adedi'] ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

</div>

<script>

document.getElementById('kategori').addEventListener('change', function () {
    const kategori = this.value;
    const markaSelect = document.getElementById('marka');
    const urunSelect = document.getElementById('urun');
    markaSelect.innerHTML = '<option>Yükleniyor...</option>';
    urunSelect.innerHTML = '<option>Önce marka seçiniz</option>';

    fetch('get_brands.php?kategori=' + encodeURIComponent(kategori))
        .then(response => response.json())
        .then(data => {
            if(data.length > 0) {
                let options = '<option value="">Seçiniz...</option>';
                data.forEach(marka => {
                    options += `<option value="${marka}">${marka}</option>`;
                });
                markaSelect.innerHTML = options;
            } else {
                markaSelect.innerHTML = '<option value="">Marka bulunamadı</option>';
            }
            urunSelect.innerHTML = '<option>Önce marka seçiniz</option>';
        });
});


document.getElementById('marka').addEventListener('change', function () {
    const kategori = document.getElementById('kategori').value;
    const marka = this.value;
    const urunSelect = document.getElementById('urun');
    urunSelect.innerHTML = '<option>Yükleniyor...</option>';

    fetch('get_products.php?kategori=' + encodeURIComponent(kategori) + '&marka=' + encodeURIComponent(marka))
        .then(response => response.json())
        .then(data => {
            if(data.length > 0) {
                let options = '<option value="">Seçiniz...</option>';
                data.forEach(urun => {
                    options += `<option value="${urun}">${urun}</option>`;
                });
                urunSelect.innerHTML = options;
            } else {
                urunSelect.innerHTML = '<option value="">Ürün bulunamadı</option>';
            }
        });
});


document.addEventListener('DOMContentLoaded', () => {
    const kategori = "<?= addslashes($kategori) ?>";
    const marka = "<?= addslashes($marka) ?>";
    const urun = "<?= addslashes($urun) ?>";

    if(kategori) {
        fetch('get_brands.php?kategori=' + encodeURIComponent(kategori))
            .then(response => response.json())
            .then(data => {
                const markaSelect = document.getElementById('marka');
                let options = '<option value="">Seçiniz...</option>';
                data.forEach(m => {
                    options += `<option value="${m}" ${m === marka ? 'selected' : ''}>${m}</option>`;
                });
                markaSelect.innerHTML = options;

                if(marka) {
                    fetch('get_products.php?kategori=' + encodeURIComponent(kategori) + '&marka=' + encodeURIComponent(marka))
                        .then(response => response.json())
                        .then(products => {
                            const urunSelect = document.getElementById('urun');
                            let uoptions = '<option value="">Seçiniz...</option>';
                            products.forEach(u => {
                                uoptions += `<option value="${u}" ${u === urun ? 'selected' : ''}>${u}</option>`;
                            });
                            urunSelect.innerHTML = uoptions;
                        });
                }
            });
    }
});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
