<?php
session_start();
include 'config.php';
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

if (isset($_GET['sell'])) {
    $id = (int)$_GET['sell'];
    $conn->query("UPDATE products SET stock = stock - 1 WHERE id = $id AND stock > 0");
}

$categories = $conn->query("SELECT DISTINCT category FROM products");
?>

<form method="GET">
    <select name="category" onchange="this.form.submit()">
        <option value="">Kategori Seçin</option>
        <?php while ($cat = $categories->fetch_assoc()): ?>
            <option value="<?= $cat['category'] ?>" <?= isset($_GET['category']) && $_GET['category'] === $cat['category'] ? 'selected' : '' ?>>
                <?= $cat['category'] ?>
            </option>
        <?php endwhile; ?>
    </select>

    <?php
    if (isset($_GET['category'])) {
        $category = $_GET['category'];
        $brands = $conn->query("SELECT DISTINCT brand FROM products WHERE category = '$category'");
        echo "<select name='brand' onchange='this.form.submit()'>";
        echo "<option value=''>Marka Seçin</option>";
        while ($b = $brands->fetch_assoc()) {
            echo "<option value='{$b['brand']}'" . (isset($_GET['brand']) && $_GET['brand'] == $b['brand'] ? 'selected' : '') . ">{$b['brand']}</option>";
        }
        echo "</select>";
    }

    if (isset($_GET['brand'])) {
        $brand = $_GET['brand'];
        $names = $conn->query("SELECT id, name, stock FROM products WHERE category = '$category' AND brand = '$brand'");
        echo "<select name='product'>";
        while ($p = $names->fetch_assoc()) {
            $disabled = $p['stock'] <= 0 ? 'disabled' : '';
            echo "<option value='{$p['id']}' $disabled>{$p['name']} (Stok: {$p['stock']})</option>";
        }
        echo "</select>";
        echo "<button type='submit' name='sell' value='{$_GET['product']}'>SAT</button>";
    }
    ?>
</form>
