<?php
require 'config.php';

$kategori = $_GET['kategori'] ?? '';
$marka = $_GET['marka'] ?? '';

if ($kategori && $marka) {
    $stmt = $pdo->prepare("SELECT DISTINCT urun_adi FROM products WHERE kategori = ? AND marka = ?");
    $stmt->execute([$kategori, $marka]);
    $urunler = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode($urunler);
} else {
    echo json_encode([]);
}
