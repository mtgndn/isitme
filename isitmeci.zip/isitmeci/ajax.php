<?php
require 'config.php';

if (!isset($_SESSION['admin'])) {
    exit('Erişim engellendi.');
}

$action = $_GET['action'] ?? '';

if ($action == 'getBrands') {
    $category_id = (int)($_GET['category_id'] ?? 0);
    if ($category_id) {
        $stmt = $pdo->prepare("SELECT * FROM brands WHERE category_id = ? ORDER BY name");
        $stmt->execute([$category_id]);
        $brands = $stmt->fetchAll();

        echo '<option value="">Seçiniz</option>';
        foreach ($brands as $brand) {
            echo "<option value='{$brand['id']}'>{$brand['name']}</option>";
        }
    } else {
        echo '<option value="">Önce kategori seçiniz</option>';
    }
    exit;
}

if ($action == 'getProducts') {
    $brand_id = (int)($_GET['brand_id'] ?? 0);
    if ($brand_id) {
        $stmt = $pdo->prepare("SELECT * FROM products WHERE brand_id = ? ORDER BY name");
        $stmt->execute([$brand_id]);
        $products = $stmt->fetchAll();

        echo '<option value="">Seçiniz</option>';
        foreach ($products as $product) {
            echo "<option value='{$product['id']}'>{$product['name']}</option>";
        }
    } else {
        echo '<option value="">Önce marka seçiniz</option>';
    }
    exit;
}

if ($action == 'getStock') {
    $product_id = (int)($_GET['product_id'] ?? 0);
    if ($product_id) {
        $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();

        if ($product) {
            $stock = (int)$product['stock'];
            $disabled = $stock == 0 ? 'disabled' : '';
            echo "Stok Adedi: <strong>$stock</strong> <button type='button' id='btnSell' $disabled>SAT</button>";
        } else {
            echo "Ürün bulunamadı.";
        }
    } else {
        echo "Ürün seçiniz.";
    }
    exit;
}

echo "Geçersiz istek.";
