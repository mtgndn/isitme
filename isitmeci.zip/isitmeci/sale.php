<?php
require 'config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['admin'])) {
    echo json_encode(['success' => false, 'message' => 'Giriş yapmalısınız.']);
    exit;
}

$product_id = (int)($_POST['product_id'] ?? 0);

if ($product_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz ürün ID.']);
    exit;
}


$stmt = $pdo->prepare("SELECT stock FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch();

if (!$product) {
    echo json_encode(['success' => false, 'message' => 'Ürün bulunamadı.']);
    exit;
}

if ($product['stock'] <= 0) {
    echo json_encode(['success' => false, 'message' => 'Stokta ürün kalmadı.']);
    exit;
}


$stmt = $pdo->prepare("UPDATE products SET stock = stock - 1 WHERE id = ?");
$stmt->execute([$product_id]);

echo json_encode(['success' => true, 'message' => 'Ürün satıldı, stok güncellendi.']);
