<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}

$kategori = $_POST['kategori'] ?? '';
$marka = $_POST['marka'] ?? '';
$urun = $_POST['urun'] ?? '';

if (!$kategori || !$marka || !$urun) {
    header("Location: index.php");
    exit;
}

$error = '';
$satildi = false;


$stmt = $pdo->prepare("SELECT * FROM products WHERE kategori = ? AND marka = ? AND urun_adi = ?");
$stmt->execute([$kategori, $marka, $urun]);
$product = $stmt->fetch();

if (!$product) {
    $error = "Ürün bulunamadı.";
} else {
    $stokAdedi = (int)$product['stok_adedi'];

    
    if (isset($_POST['sat'])) {
        if ($stokAdedi > 0) {
            $stokAdedi--;
            $updateStmt = $pdo->prepare("UPDATE products SET stok_adedi = ? WHERE id = ?");
            $updateStmt->execute([$stokAdedi, $product['id']]);
            $satildi = true;
        } else {
            $error = "Stokta yeterli ürün yok.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8" />
    <title>Stok Sonucu ve Satış</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
<div class="container mt-4">

    <h2>Ürün: <?=htmlspecialchars($kategori)?> / <?=htmlspecialchars($marka)?> / <?=htmlspecialchars($urun)?></h2>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?=htmlspecialchars($error)?></div>
    <?php endif; ?>

    <?php if ($satildi): ?>
        <div class="alert alert-success">Ürün başarıyla satıldı, stok güncellendi.</div>
    <?php endif; ?>

    <?php if ($product): ?>
        <p>Stok Adedi: <strong><?= $stokAdedi ?></strong></p>

        <form method="post">
            
            <input type="hidden" name="kategori" value="<?=htmlspecialchars($kategori)?>">
            <input type="hidden" name="marka" value="<?=htmlspecialchars($marka)?>">
            <input type="hidden" name="urun" value="<?=htmlspecialchars($urun)?>">
            <button type="submit" name="sat" class="btn btn-success" <?= $stokAdedi == 0 ? 'disabled' : '' ?>>SAT</button>
        </form>
    <?php endif; ?>

    <hr>
    <a href="index.php" class="btn btn-secondary mt-3">Geri Dön</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
