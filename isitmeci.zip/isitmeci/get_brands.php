<?php
require 'config.php';

$kategori = $_GET['kategori'] ?? '';

if ($kategori) {
    $stmt = $pdo->prepare("SELECT DISTINCT marka FROM products WHERE kategori = ?");
    $stmt->execute([$kategori]);
    $markalar = $stmt->fetchAll(PDO::FETCH_COLUMN);
    echo json_encode($markalar);
} else {
    echo json_encode([]);
}
